package e2017.exam3;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class Example4 {
    public static void main(String[] args) {
        String s = "<tr><td>ȫ�浿</td><td>18</td></tr><tr><td>�Ӳ���</td><td>19</td></tr>" +
                   "<span>false</span><div><span>true</span></div>";


    }
}
