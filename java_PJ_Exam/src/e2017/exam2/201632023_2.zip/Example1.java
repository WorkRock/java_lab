package e2017.exam2;

public class Example1 {

	public static void main(String[] args) { 
		String[] a = { "d", "a", "b", "a", "c", "d", "e", "f", "e" };
		int size = a.length;
		String[] b = new String[size];
		//int error = 0;
		for(int i = 0; i<size; ++i) {
			for(int j = 0; j<size; ++j) {
				if(a[j] == a[i]) {
					b[i] = a[i];
					break;
				}
			}
			System.out.print(b[i] + " ");
		}
	}
}
