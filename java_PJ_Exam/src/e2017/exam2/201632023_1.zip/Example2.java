package e2017.exam2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Example2 {
	String[] a1 = { "d", "a", "b", "a", "c", "a" }; 
	String[] a2 = { "b", "a", "f", "e", "b", "b" };
}
