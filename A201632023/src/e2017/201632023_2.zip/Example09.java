package e2017.exam1;
class Data {
	
} 
public class Example09 { 
	public static void main(String[] args) {
		Data[] a = new Data[3];
		a[0] = (Data) new Object();
		a[2] = (Data) new Object();
		a[3] = (Data) new Object();
	}
}