package e2017.exam1;
class Data {
	Object obj = new Object();
	public Data(Object obj) {
		
	}
} 
public class Example09 { 
	public static void main(String[] args) {
		Data[] a = new Data[3];
		Object obj = new int[] {1,2,3};
		a[0] = new Data(obj);
		obj = new Integer[] {1,2,3};
		a[1] = new Data(obj);
		obj = new String("hello");
		a[2] = new Data(obj);
	}
}